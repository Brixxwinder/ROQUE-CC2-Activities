import java.util.*;

public class Simple_Calculator {
	public static void main(String[] brixx) {
		Scanner sc = new Scanner (System.in);
	
		String s = "";
		int numOperation;
		int input1, input2;
		
		//Enter # of operations here
		System.out.print("Enter # of operations: ");
		numOperation = sc.nextInt();
		//Enter all operations in one line here
		if (numOperation >= 1 && numOperation <= 100) {
			System.out.print("Enter all operations in one line: ");
			for (int initialNum = 1; initialNum <= numOperation; initialNum++) {
				s = sc.next();
				//if operation is negate
				if (s.equals("negate")) {
					input1 = sc.nextInt();
					System.out.println(-input1);
				//if operation is add
				}else if (s.equals("add")) {
					input1 = sc.nextInt();
					input2 = sc.nextInt();
					System.out.println(input1 + input2);
				//if operation is max
				}else if (s.equals("max")) {
					input1 = sc.nextInt();
					input2 = sc.nextInt();
					if (input1 > input2)
					System.out.println(input1);
					else
					System.out.println(input2);
				}else {
					System.out.println("Invalid Input");
				}
			}
		}else {
			System.out.println("Invalid Input");
		}
	}
}