public class VariablesAndDataTypes{

    public static void main(String[]args){
      String sentence1 = "The temperature in Baguio City has warmed throughout the years.";
      String letter = "A";
        
      double temp1 = 16.0d;
      float temp2 = 23.5f;
          
      byte time_hours = 24;
      short time_weeks1 = 7;
      int time_weeks2 = 4;
      long time_months = 12;
          
      boolean warmed = true;
        if (warmed) {
          System.out.print(sentence1 + "\n");
          System.out.print("\t" + letter + " recent news article stated that the City has been averaging " + temp1 + " degrees celsius at dawn and " + temp2 + " at noon.\n");
          System.out.print("\t\tRegardless, lowlanders still feel cold " + time_hours + " hours a day, " + time_weeks1 + " days a week, " + time_weeks2 + " weeks per month and " + time_months + " months each year.");
        }
        else {
          System.out.print("The boolean was changed to a false value.");
        }
    }
}