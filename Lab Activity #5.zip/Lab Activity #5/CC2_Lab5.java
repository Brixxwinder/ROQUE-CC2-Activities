public class CC2_Lab5 {
 	public static void main(String[] args) {
	
		 double rand = Math.random() * 1000;
		 int messageCount = (int)rand;
		 float charges = 0.5f;
		 int messageLimit = 200;
		 
		 if (messageCount > 200) {
			System.out.println("You have sent " + messageCount + " messages.");
			System.out.println("You have incurred " + (messageCount-messageLimit)*charges + " PHP in charges.");
		}
	}
}