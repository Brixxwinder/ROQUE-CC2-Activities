public class Tree{
    public static void main(String[]args){
        System.out.print("   X\n");
        System.out.print("  XXX\n");
        System.out.print(" XXXXX\n");
        System.out.print("XXXXXXX\n");
        System.out.print("   X");
    }
}