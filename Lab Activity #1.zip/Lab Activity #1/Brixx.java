public class Brixx{
	public static void main(String[] args){
    	System.out.print("Brixx");
    	System.out.print(" Cruz ");
    	System.out.print("Roque\n");
    	System.out.print("22\n");
    	System.out.print("Computer Science\n");
    	System.out.print("Orani, Bataan\n");
 	}
}