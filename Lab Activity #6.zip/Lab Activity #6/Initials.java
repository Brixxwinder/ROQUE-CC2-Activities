import javax.swing.*;

public class Initials {
	public static void main(String[] args) {
		
		String firstName = "";
		String middleName = "";
		String lastName = "";
		
		firstName = JOptionPane.showInputDialog ("Enter your first name's initial:");
		middleName = JOptionPane.showInputDialog ("Enter your middle name's initial:");
		lastName = JOptionPane.showInputDialog ("Enter your last name's initial:");

		char initial1 = firstName.charAt(0);
		char initial2 = middleName.charAt(0);
		char initial3 = lastName.charAt(0);
		JOptionPane.showMessageDialog(null, initial1+"." + initial2+"." + initial3+".");
	}
}