import javax.swing.*;
import java.text.DecimalFormat;

public class Simulation_1D_Arrays {
	public static void main(String[] brixx) {
		DecimalFormat dc = new DecimalFormat("0.00");
		double weekGross;
		int anotherInput;
		

		try{
			System.out.println("---------- TRYING SIMULATION ----------");
			for (int input = 1; input > 0; input++){
				weekGross = Double.parseDouble(JOptionPane.showInputDialog("Input salary: "));

				double weekBonus = weekGross*0.09, weekTotal = weekBonus+200;

				if (weekGross >= 0 && weekGross <= 100000) {
					System.out.println("Employee #" + input);
					System.out.println("Week Gross "+input + ": " + dc.format(weekGross));
					System.out.println("Week Bonus "+input + ": " + dc.format(weekBonus));
					System.out.println("Week Total "+input + ": " + dc.format(weekTotal));
				}else if (weekGross < 0 || weekGross > 100000){
					System.out.println("----------  SIMULATION FAIL  ----------");
					break;
				}
				if (weekTotal >= 200 && weekTotal <= 299) {
					System.out.println("Classfication " + input +": A");
				}else if (weekTotal >= 300 && weekTotal <= 399){
					System.out.println("Classfication " + input +": B");
				}else if (weekTotal >= 400 && weekTotal <= 499){
					System.out.println("Classfication " + input +": C");
				}else if (weekTotal >= 500 && weekTotal <= 599){
					System.out.println("Classfication " + input +": D");
				}else if (weekTotal >= 600 && weekTotal <= 699){
					System.out.println("Classfication " + input +": E");
				}else if (weekTotal >= 700 && weekTotal <= 799){
					System.out.println("Classfication " + input +": F");
				}else if (weekTotal >= 800 && weekTotal <= 899){
					System.out.println("Classfication " + input +": G");
				}else if (weekTotal >= 900 && weekTotal <= 999){
					System.out.println("Classfication " + input +": H");
				}else if (weekTotal >= 1000){
					System.out.println("Classfication " + input +": I");
				}
				System.out.println("----------");
				anotherInput = Integer.parseInt(JOptionPane.showInputDialog("Enter another Employee? \n[0]YES \n[1]NO"));
				if (anotherInput == 1)
					break;
			}
		}catch(Exception E){
			System.out.println("----------  SIMULATION FAIL  ----------");
		}
	}
}