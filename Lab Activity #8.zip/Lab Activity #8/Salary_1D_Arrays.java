import javax.swing.*;
import java.text.DecimalFormat;

public class Salary_1D_Arrays {
	public static void main(String[] brixx) {
		DecimalFormat df = new DecimalFormat("0.00");
		double weekGross;
		int anotherInput;
		int [] payRanges = {200, 300, 400, 500, 600, 700, 800, 900, 1000};
		char [] classLabels = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'};
		int [] classNumbers = new int [9];

		

		try{
			System.out.println("---------- TRYING SIMULATION ----------");
			for (int input = 1; input > 0; input++){
				//INPUT EMPLOYEE GROSS
				weekGross = Double.parseDouble(JOptionPane.showInputDialog("Employee #" + input + " gross:"));
				//CALCULATION
				double weekBonus = weekGross*0.09, weekTotal = weekBonus+200;
				if (weekGross >= 0 && weekGross <= 100000) {
					System.out.println("Employee #" + input);
					System.out.println("Week Gross "+input + ": " + df.format(weekGross));
					System.out.println("Week Bonus "+input + ": " + df.format(weekBonus));
					System.out.println("Week Total "+input + ": " + df.format(weekTotal));
				}else if (weekGross < 0 || weekGross > 100000){
					System.out.println("----------  SIMULATION FAIL  ----------");
					break;
				}if (weekTotal >= payRanges[0])
					System.out.println("Classification " + input + ": ");
				System.out.println("----------");
				//IF YOU WANT TO INPUT ANOTHER EMPLOYEE
				anotherInput = Integer.parseInt(JOptionPane.showInputDialog("Enter another Employee? \n[0]YES \n[1]NO"));
				if (anotherInput == 1)
					break;
			}
		}catch(Exception E){
			System.out.println("----------  GENESIS  ----------");
		}
	}
}