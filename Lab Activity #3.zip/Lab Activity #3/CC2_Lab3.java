public class CC2_Lab3 {
	public static void main(String[] args) {
		
		char letter1 = 'B', letter2 = 'R', letter3 = 'I', letter4 = 'X', letter5 = 'X', pMark = '!';
		
		int asciiCode1 = letter1, asciiCode2 = letter2, asciiCode3 = letter3, asciiCode4 = letter4, asciiCode5 = letter5, asciiCodePM = pMark;
		int sum = letter1 + letter2 + letter3 + letter4 + letter5 + pMark;
		long product = (long)letter1 * letter2 * letter3 * letter4 * letter5 * pMark;
		int average = sum / 6, remainder = sum % 6;
					
		System.out.println(letter1 + " - " + asciiCode1);
		System.out.println(letter2 + " - " + asciiCode2);
		System.out.println(letter3 + " - " + asciiCode3);
		System.out.println(letter4 + " - " + asciiCode4);
		System.out.println(letter5 + " - " + asciiCode5);
		System.out.println(pMark + " - " + asciiCodePM);
		System.out.println(letter1 +""+ letter2 +""+ letter3 +""+ letter4 +""+ letter5 +""+ pMark);
		System.out.println("Sum: " + sum);
		System.out.println("Product: " + product);
		System.out.println("Average: " + average);
		System.out.println("Remainder: " + remainder);
	}
}